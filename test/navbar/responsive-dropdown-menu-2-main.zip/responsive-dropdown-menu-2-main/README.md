# Responsive Dropdown Menu
## [Watch it on youtube](https://youtu.be/rlFjsp4BtRA)
### Dropdown Menu

- Responsive Dropdown Menu Using HTML CSS & JavaScript
- Contains a responsive navigation bar.
- Contains dropdown menu & a submenu.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
